package win.kakchuserver.playerlisttoggle.mixin;

import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import win.kakchuserver.playerlisttoggle.PlayerListToggleConfig;
import win.kakchuserver.playerlisttoggle.PlayerListToggleState;

@Mixin(class_304.class)
public abstract class KeyBindingMixin {
    @Inject(method = "setKeyPressed", at = @At("HEAD"))
    private static void playerlisttoggle$setKeyPressed(class_3675.class_306 key, boolean pressed, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            return;
        }

        class_304 playerListKey = client.field_1690.field_1907;
        class_3675.class_306 boundKey = ((KeyBindingAccessor) (Object) playerListKey).playerlisttoggle$getBoundKey();

        if (boundKey.equals(key)) {
            PlayerListToggleState.playerListDown(pressed);

            if (PlayerListToggleConfig.enabled() && pressed) {
                PlayerListToggleState.toggle();
            }
        }
    }

    @Inject(method = "isPressed", at = @At("HEAD"), cancellable = true)
    private void playerlisttoggle$isPressed(CallbackInfoReturnable<Boolean> cir) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null || client.field_1755 != null) {
            return;
        }

        if (!PlayerListToggleConfig.enabled()) {
            return;
        }

        class_304 self = (class_304) (Object) this;
        if (self == client.field_1690.field_1907) {
            cir.setReturnValue(PlayerListToggleState.toggled());
        }
    }
}
